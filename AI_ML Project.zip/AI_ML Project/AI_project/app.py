# import streamlit as st
# import pandas as pd
# import matplotlib.pyplot as plt
# from src.ai_engine import preprocess, monthly_data, predict, detect_anomaly, classify, generate_insights

# st.set_page_config(page_title="AI Ledger Engine", layout="wide")

# st.title("🏦 AI-Based Financial Ledger Engine")

# # ✅ Upload file
# file = st.file_uploader("Upload Transaction Excel File", type=["xlsx"])


# # ✅ Inputs
# col1, col2 = st.columns(2)

# with col1:
#     acc = st.text_input("Enter Account Number")

# with col2:
#     months = st.number_input("Months to Predict", min_value=1, max_value=24, value=6)

# # ✅ Run button
# if st.button("Run AI Analysis"):

#     if file is None or acc == "":
#         st.error("Please upload file and enter account number")

#     else:
#         try:
#             df = pd.read_excel(file)

#             # ✅ Preprocess
#             df = preprocess(df, acc)

#             if df.empty:
#                 st.warning("No data found for this account")
#             else:
#                 # ✅ Classification
#                 df = classify(df)

#                 # ✅ Monthly aggregation
#                 monthly_df = monthly_data(df)

#                 # ✅ Prediction
#                 forecast = predict(monthly_df, months)

#                 # ✅ Anomaly detection
#                 anomalies = detect_anomaly(df)

#                 # ✅ AI Insights
#                 insight = generate_insights(monthly_df)

#                 # ================= OUTPUT =================

#                 # ✅ User-friendly Monthly History
#                 monthly_display = monthly_df.copy()
#                 monthly_display.rename(columns={
#                     'ds': 'Month',
#                     'y': 'Total Transaction Amount'
#                 }, inplace=True)

#                 # Format date
#                 monthly_display['Month'] = pd.to_datetime(monthly_display['Month']).dt.strftime('%b-%Y')

#                 st.subheader("📊 Monthly Transaction History")
#                 st.dataframe(monthly_display)

#                 # ✅ User-friendly Prediction
#                 forecast_display = forecast.tail(months).copy()
#                 forecast_display.rename(columns={
#                     'ds': 'Month',
#                     'yhat': 'Predicted Amount'
#                 }, inplace=True)

#                 forecast_display['Month'] = pd.to_datetime(forecast_display['Month']).dt.strftime('%b-%Y')

#                 st.subheader("🔮 Monthly Prediction")
#                 st.dataframe(forecast_display)

#                 # ✅ Anomalies
#                 st.subheader("⚠️ Suspicious Transactions")
#                 if anomalies.empty:
#                     st.success("No suspicious transactions detected ✅")
#                 else:
#                     st.dataframe(anomalies)

#                 # ✅ AI Insight
#                 st.subheader("🧠 AI Insight")
#                 st.success(insight)

#                 # ✅ Simple Chart (User-friendly)
#                 st.subheader("📈 Monthly Trend")

#                 # Prepare data
#                 actual_values = monthly_df['y'].tolist()
#                 predicted_values = forecast.tail(months)['yhat'].tolist()

#                 actual_months = monthly_df['ds']
#                 predicted_months = forecast.tail(months)['ds']
#                 actual_labels = actual_months.dt.strftime('%b-%Y').tolist()
#                 predicted_labels = predicted_months.dt.strftime('%b-%Y').tolist()
#                 all_labels = actual_labels + predicted_labels
#                 full_values = actual_values + predicted_values
#                 # Plot
#                 fig, ax = plt.subplots()

#                 ax.plot(all_labels[:len(actual_values)],
#         actual_values,
#         marker='o',
#         label="Actual")

#                 ax.plot(all_labels[len(actual_values):],
#         predicted_values,
#         marker='o',
#         linestyle='--',
#         label="Predicted")
                

#                 ax.set_xticks(range(len(all_labels)))
#                 ax.set_xticklabels(all_labels, rotation=45)

#                 ax.set_xlabel("Month")
#                 ax.set_ylabel("Transaction Amount (₹)")
#                 ax.set_title("Monthly Transaction Prediction")

#                 ax.legend()
#                 ax.grid(True)

#                 st.pyplot(fig)
#                 # ✅ Download option
#                 output_file = "monthly_prediction.xlsx"
#                 forecast_display.to_excel(output_file, index=False)

#                 with open(output_file, "rb") as file:
#                     st.download_button(
#                         label="Download Prediction",
#                         data=file,
#                         file_name="monthly_prediction.xlsx",
#                         mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#                     )

#         except Exception as e:
#             st.error(f"Error occurred: {e}")

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from src.ai_engine import preprocess, monthly_data, predict, detect_anomaly, classify, generate_insights

# ✅ Page setup
st.set_page_config(page_title="AI Ledger Engine", layout="wide")
st.title("🏦 AI-Based Financial Ledger Engine")

# ================= SESSION STATE =================
if "file_uploaded" not in st.session_state:
    st.session_state.file_uploaded = False

# ================= FILE UPLOAD =================
file = st.file_uploader(
    "Upload Transaction Excel File",
    type=["xlsx"],
    disabled=st.session_state.file_uploaded
)

# Lock upload after first file
if file is not None and not st.session_state.file_uploaded:
    st.session_state.file_uploaded = True

# ✅ Reset option
if st.session_state.file_uploaded:
    if st.button("Reset File"):
        st.session_state.file_uploaded = False
        st.rerun()

# ================= INPUTS =================
col1, col2 = st.columns(2)

with col1:
    acc = st.text_input("Enter Account Number")

with col2:
    months = st.number_input("Months to Predict", min_value=1, max_value=24, value=6)

# ================= RUN BUTTON =================
if st.button("Run AI Analysis"):

    if file is None or acc.strip() == "":
        st.error("Please upload file and enter account number")

    else:
        try:
            # ✅ File validation (optional but recommended)
            if file.size > 1024 * 1024:
                st.error("File size must be less than 1MB")
                st.stop()

            # ✅ Read Excel
            df = pd.read_excel(file)

            # ✅ Preprocess
            df = preprocess(df, acc)

            if df.empty:
                st.warning("No data found for this account")

            else:
                # ✅ Classification
                df = classify(df)

                # ✅ Monthly aggregation
                monthly_df = monthly_data(df)

                # ✅ Prediction
                forecast = predict(monthly_df, months)

                # ✅ Anomaly detection
                anomalies = detect_anomaly(df)

                # ✅ AI Insight
                insight = generate_insights(monthly_df)

                # ================= OUTPUT =================

                # ✅ Monthly History
                monthly_display = monthly_df.copy()
                monthly_display.rename(columns={
                    'ds': 'Month',
                    'y': 'Total Transaction Amount'
                }, inplace=True)

                monthly_display['Month'] = pd.to_datetime(
                    monthly_display['Month']).dt.strftime('%b-%Y')

                st.subheader("📊 Monthly Transaction History")
                st.dataframe(monthly_display, use_container_width=True)

                # ✅ Prediction
                forecast_display = forecast.tail(months).copy()
                forecast_display.rename(columns={
                    'ds': 'Month',
                    'yhat': 'Predicted Amount'
                }, inplace=True)

                forecast_display['Month'] = pd.to_datetime(
                    forecast_display['Month']).dt.strftime('%b-%Y')

                st.subheader("🔮 Monthly Prediction")
                st.dataframe(forecast_display, use_container_width=True)

                # ✅ Anomalies
                st.subheader("⚠️ Suspicious Transactions")
                if anomalies.empty:
                    st.success("No suspicious transactions detected ✅")
                else:
                    st.dataframe(anomalies, use_container_width=True)

                # ✅ AI Insight
                st.subheader("🧠 AI Insight")
                st.success(insight)

                # ================= CHART =================
                st.subheader("📈 Monthly Trend")

                actual_values = monthly_df['y'].tolist()
                predicted_values = forecast.tail(months)['yhat'].tolist()

                actual_months = monthly_df['ds']
                predicted_months = forecast.tail(months)['ds']

                actual_labels = actual_months.dt.strftime('%b-%Y').tolist()
                predicted_labels = predicted_months.dt.strftime('%b-%Y').tolist()

                all_labels = actual_labels + predicted_labels

                fig, ax = plt.subplots()

                ax.plot(actual_labels, actual_values,
                        marker='o', label="Actual")

                ax.plot(predicted_labels, predicted_values,
                        marker='o', linestyle='--', label="Predicted")

                ax.set_xticks(range(len(all_labels)))
                ax.set_xticklabels(all_labels, rotation=45)

                ax.set_xlabel("Month")
                ax.set_ylabel("Transaction Amount (₹)")
                ax.set_title("Monthly Transaction Prediction")

                ax.legend()
                ax.grid(True)

                st.pyplot(fig)

                # ================= DOWNLOAD =================
                output_file = "monthly_prediction.xlsx"
                forecast_display.to_excel(output_file, index=False)

                with open(output_file, "rb") as f:
                    st.download_button(
                        label="Download Prediction",
                        data=f,
                        file_name="monthly_prediction.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )

        except Exception as e:
            st.error(f"Error occurred: {e}")