import pandas as pd
from prophet import Prophet
from sklearn.ensemble import IsolationForest

# ✅ Preprocess
def preprocess(df, account_no):
    df['TRA_DT'] = pd.to_datetime(df['TRA_DT'])
    df = df[df['ACCOUNT_NO'] == int(account_no)]
    return df


# ✅ Monthly Aggregation
def monthly_data(df):
    df['Month'] = df['TRA_DT'].dt.to_period('M')

    monthly = df.groupby('Month')['AMOUNT'].sum().reset_index()

    monthly['ds'] = monthly['Month'].dt.to_timestamp()
    monthly['y'] = monthly['AMOUNT']

    return monthly[['ds', 'y']]


# ✅ Forecasting
def predict(monthly_df, months):
    model = Prophet()
    model.fit(monthly_df)

    future = model.make_future_dataframe(periods=months, freq='M')
    forecast = model.predict(future)

    return forecast[['ds', 'yhat']]


# ✅ Anomaly Detection
def detect_anomaly(df):
    df['hour'] = df['TRA_DT'].dt.hour

    features = df[['AMOUNT', 'hour']]

    model = IsolationForest(contamination=0.05)
    df['anomaly'] = model.fit_predict(features)

    anomalies = df[df['anomaly'] == -1]

    def reason(row):
        if row['AMOUNT'] > df['AMOUNT'].mean() * 2:
            return "High Amount"
        elif row['hour'] < 6 or row['hour'] > 22:
            return "Odd Time Transaction"
        else:
            return "Unusual Pattern"

    anomalies['reason'] = anomalies.apply(reason, axis=1)

    return anomalies


# ✅ Classification
def classify(df):

    def classify_text(desc):
        desc = str(desc).upper()

        if "INT" in desc:
            return "INTEREST"
        elif "TRANSFER" in desc:
            return "TRANSFER"
        elif "FEE" in desc:
            return "FEE"
        else:
            return "GENERAL"

    df['CATEGORY'] = df['DESCR'].apply(classify_text)

    return df


# ✅ AI Insights
def generate_insights(monthly_df):

    trend = monthly_df['y'].pct_change().mean()

    if trend > 0:
        return "📈 Transactions are increasing over time"
    elif trend < 0:
        return "📉 Transactions are decreasing"
    else:
        return "⚖️ Transactions are stable"
    